<?php

require_once "controleur/routeurControleur.php";

$routeur = new RouteurControleur();
$routeur->routerRequete();

?>